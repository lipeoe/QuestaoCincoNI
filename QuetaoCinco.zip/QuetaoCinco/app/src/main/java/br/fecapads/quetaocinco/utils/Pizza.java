package br.fecapads.quetaocinco.utils;

public class Pizza {
    private String nome;
    private String tamanho;
    private int valor;

    public Pizza(String nome, String tamanho, int valor) {
        this.nome = nome;
        this.tamanho = tamanho;
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
