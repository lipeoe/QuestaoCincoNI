package br.fecapads.quetaocinco.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import br.fecapads.quetaocinco.R;

public class PedidoActivity extends AppCompatActivity {
    private Button btnGoToResumo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pedido);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.pedido), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnGoToResumo = findViewById(R.id.btnGoToResumo);
        btnGoToResumo.setOnClickListener(view ->{
            Intent intent = new Intent(this, ResumoActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
